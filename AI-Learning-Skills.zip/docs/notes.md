# Notes

Hier komen mijn notities en leerpunten.