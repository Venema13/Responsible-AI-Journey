# main.py
# Eerste Python script voor AI Learning Skills

def hello():
    print("Welkom bij mijn eerste AI-project!")

if __name__ == "__main__":
    hello()
